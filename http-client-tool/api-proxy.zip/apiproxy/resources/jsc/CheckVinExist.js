var vinDetails= context.getVariable("agero.vinDetails");
var vinDetailsJson = new String(vinDetails);
//var vehicles = vinDetails.vehicle;
isVinInList = "false";
vin = context.getVariable("vin")
if (vinDetailsJson.indexOf(vin) > 1) {
	isVinInList = "true";
}
context.setVariable("isVinInList",isVinInList)