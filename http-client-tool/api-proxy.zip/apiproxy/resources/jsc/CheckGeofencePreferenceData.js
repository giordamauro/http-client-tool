isPrefIdFound = "false";
var preferenceListObj = context.getVariable("preferenceList");
var preferenceIdObj = context.getVariable("preferenceId");
preferenceList = new String(preferenceListObj);
preferenceId = new String(preferenceIdObj);
updatedList = preferenceList.replace(/{}/g,'""');
if( updatedList.indexOf("]") < 1) {
	updatedList = "["+updatedList+"]";
}
jsonResp = eval(updatedList);
for (i in jsonResp)
{
 var prefDetails = jsonResp[i];
 if (preferenceId == prefDetails.fenceId ){
        context.setVariable("fenceName",prefDetails.fenceName);
        context.setVariable("fenceType",prefDetails.fenceType);
        context.setVariable("alertType",prefDetails.alertType);
        context.setVariable("radius.unit",prefDetails.radius.unit);
        context.setVariable("radius.value",prefDetails.radius.value);
        context.setVariable("center.latitude",prefDetails.center.latitude);
        context.setVariable("center.longitude",prefDetails.center.longitude);
        context.setVariable("center.address.aptNumber",prefDetails.center.address.aptNumber);
        context.setVariable("center.address.street1",prefDetails.center.address.street1);
        context.setVariable("center.address.street2",prefDetails.center.address.street2);
        context.setVariable("center.address.city",prefDetails.center.address.city);
        context.setVariable("center.address.zipCode",prefDetails.center.address.zipCode);
        context.setVariable("center.address.state",prefDetails.center.address.state);
        context.setVariable("center.address.subRegion",prefDetails.center.address.subRegion);
        context.setVariable("timeInterval",prefDetails.timeInterval);
        context.setVariable("bufferDistance.unit",prefDetails.bufferDistance.unit);
        context.setVariable("bufferDistance.value",prefDetails.bufferDistance.value);
        isPrefIdFound = "true";
        break;
        }
}
context.setVariable("isPrefIdFound",isPrefIdFound);
