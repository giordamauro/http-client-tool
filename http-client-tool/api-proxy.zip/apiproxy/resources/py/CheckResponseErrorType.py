errorType = flow.getVariable("errorType")
statusCode = "500"
reasonPhrase = "ERROR"
if ((errorType is not None) and (errorType == "VALIDATION_ERROR")):
    statusCode = "400"
    reasonPhrase = "Bad Request"
flow.setVariable("statusCode", statusCode)
flow.setVariable("reasonPhrase",reasonPhrase)