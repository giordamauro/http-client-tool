copyProxyPath = False
flow.setVariable("target.copy.pathsuffix",copyProxyPath)
flow.setVariable("target.copy.queryparams",copyProxyPath)