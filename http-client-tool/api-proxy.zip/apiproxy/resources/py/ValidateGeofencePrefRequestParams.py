fenceName=flow.getVariable("fenceName")
fenceType=flow.getVariable("fenceType")
alertType=flow.getVariable("alertType")
validationError = "false"
if (fenceName is None or fenceName == ""):
    validationError= "missing Fence Name in the request"
elif ((fenceType is None) or (str(fenceType) != "0" and str(fenceType) != "1")):
    validationError= "Invalid Fence type. Fence type should be 0"
elif (alertType is None or alertType== ""):
    validationError= "missing alert type in the request"

flow.setVariable("validationError",validationError)