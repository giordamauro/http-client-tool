folderIdStr = flow.getVariable("folderId")
channelIdStr = flow.getVariable("channelId")
validationError = "false"
folderId = int(folderIdStr)
channelId = int(channelIdStr)
if (folderId == 2 and (channelId <33 or channelId > 38)):
    validationError = "Channel Id specified is invalid"
elif (folderId == 3 and (channelId <49 or channelId > 54)):
    validationError = "Channel Id specified is invalid"
elif (folderId == 4 and (channelId <65 or channelId > 70)):
    validationError = "Channel Id specified is invalid"
elif (folderId == 5 and (channelId <81 or channelId > 86)):
    validationError = "Channel Id specified is invalid"
elif (folderId == 6 and (channelId <97 or channelId > 102)):
    validationError = "Channel Id specified is invalid"
elif (folderId == 7 and (channelId <113 or channelId > 118)):
    validationError = "Channel Id specified is invalid"

flow.setVariable("validationError", validationError)