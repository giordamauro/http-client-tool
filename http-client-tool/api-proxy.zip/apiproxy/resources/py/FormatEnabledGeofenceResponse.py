responseContent = flow.getVariable("message.content")
if(responseContent != "{}"):
    geoFenceListStart = "{\"geoFenceList\":{"
    geoFenceListEnd = "0\"}}"
    responseContent1 = responseContent.replace(geoFenceListStart,"{\"geoFenceList\":[{")
    responseContent2 = responseContent1.replace(geoFenceListEnd,"0\"}]}")
    flow.setVariable("message.content",responseContent2)