elementIdStr = flow.getVariable("elementId")
validationError = "false"
elementId = int(elementIdStr)
if (elementId <1 or elementId > 6):
    validationError = "Invalid Element Id specified in the request"

flow.setVariable("validationError", validationError)