id=flow.getVariable("id")
timeInterval=flow.getVariable("timeInterval")
startDateTime=flow.getVariable("startDateTime")
endDateTime=flow.getVariable("endDateTime")
validationError = "false"
if (id is None or id == ""):
    validationError= "missing id in the request"
elif (timeInterval is None or timeInterval == ""):
    validationError= "missing timeInterval in the request"
elif (startDateTime is None or startDateTime == ""):
    validationError= "missing startDateTime in the request"
elif (startDateTime is None or startDateTime == ""):
    validationError= "missing endDateTime in the request"

flow.setVariable("validationError",validationError)