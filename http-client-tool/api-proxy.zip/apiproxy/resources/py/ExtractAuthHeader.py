from com.apigee.util import Crypto
authHeader=flow.getVariable("request.header.Authorization")
if (authHeader is not None and authHeader != ""):
	clientCredential=Crypto.base64decode(authHeader).split(':')
	flow.setVariable("request.header.apikey",clientCredential[0])
	flow.setVariable("request.header.apisecret",clientCredential[1])