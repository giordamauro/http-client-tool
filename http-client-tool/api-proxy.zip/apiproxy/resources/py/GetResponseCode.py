str1=flow.getVariable("message.status.code");
str2=flow.getVariable("response.status.code");
flow.setVariable("message_status",str1);
flow.setVariable("response_status",str2);  


 
