responseContent = flow.getVariable("message.content")
if(responseContent != "{}"):
    geoFenceListStart = "{\"geoFencePreferenceList\":{"
    geoFenceListEnd = "\"serviceRequestId\":{}}}"
    responseContent1 = responseContent.replace(geoFenceListStart,"{\"geoFencePreferenceList\":[{")
    responseContent2 = responseContent1.replace(geoFenceListEnd,"\"serviceRequestId\":{}}]}")
    flow.setVariable("message.content",responseContent2)