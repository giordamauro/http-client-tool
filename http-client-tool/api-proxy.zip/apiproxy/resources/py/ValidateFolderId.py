folderIdStr = flow.getVariable("folderId")
validationError = "false"
folderId = int(folderIdStr)
if (folderId <2 or folderId > 7):
    validationError = "Invalid Folder id specified in the request"

flow.setVariable("validationError", validationError)