responseContent = flow.getVariable("message.content")
responseContent1 = responseContent.replace("geoFencePreferenceList","geofencesList")
flow.setVariable("message.content",responseContent1)