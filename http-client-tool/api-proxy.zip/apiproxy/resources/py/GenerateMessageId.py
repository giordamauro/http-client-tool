import java.util.UUID;

messageId = java.util.UUID.randomUUID().toString()
flow.setVariable("messageId", messageId)