requestContent = flow.getVariable("request.content")
xmlTag = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
requestXmlRoot = requestContent.replace(xmlTag,"")
requestXmlRoot1 = requestXmlRoot.replace("</Root>","")
requestXml = requestXmlRoot1.replace("<Root>","")
flow.setVariable("requestXml",requestXml)