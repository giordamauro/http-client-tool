flow.setVariable("response.header.Content-Type","application/xml")
